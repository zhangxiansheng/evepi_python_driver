#Author:Zhang Yiwei
#Email:
#!/usr/bin/env python
"""jerk.py is a simple library to make python more python"""

__version__ = "0.2"
__author__ = "Zhang Yiwei <Karl1991223@126.com>"
__license__ = "public domain"